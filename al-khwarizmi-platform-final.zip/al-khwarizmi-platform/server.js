const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production';
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'public', 'uploads');
fs.mkdirSync(DATA_DIR, {recursive:true});
fs.mkdirSync(UPLOAD_DIR, {recursive:true});
const DB_FILE = path.join(DATA_DIR, 'db.json');

function loadDb(){
  if(!fs.existsSync(DB_FILE)){
    const teacherPass = bcrypt.hashSync('123456', 10);
    const studentPass = bcrypt.hashSync('123456', 10);
    const db = {users:[
      {id:'teacher-1',name:'محمد جمال البدري',email:'teacher@khwarizmi.test',phone:'',password:teacherPass,role:'admin',grade:'all'},
      {id:'student-1',name:'أحمد ناصر إبراهيم',email:'student@khwarizmi.test',phone:'',password:studentPass,role:'student',grade:'الثانية الثانوية باكالوريا'}
    ], materials:[
      {id:'m1',title:'الجبر',description:'أساسيات الجبر والمعادلات',lessons:14},
      {id:'m2',title:'الهندسة',description:'الهندسة المستوية والفراغية',lessons:10},
      {id:'m3',title:'الدوال',description:'فهم الدوال وتمثيلاتها',lessons:12},
      {id:'m4',title:'التفاضل والتكامل',description:'المشتقات والتكامل وتطبيقاتهما',lessons:16}
    ], lessons:[], exams:[], pdfs:[]};
    fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2));
    return db;
  }
  return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));
}
let db = loadDb();
function save(){fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2));}
function publicUser(u){return {id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role,grade:u.grade};}
function auth(req,res,next){
  const token=(req.headers.authorization||'').replace('Bearer ','');
  try{req.user=jwt.verify(token,JWT_SECRET);next();}catch(e){res.status(401).json({message:'انتهت الجلسة أو بيانات الدخول غير صحيحة'});}
}
function admin(req,res,next){if(req.user.role!=='admin')return res.status(403).json({message:'غير مصرح'});next();}
const storage = multer.diskStorage({destination:UPLOAD_DIR,filename:(req,file,cb)=>{
  const ext=path.extname(file.originalname).toLowerCase();
  cb(null, `${Date.now()}-${crypto.randomBytes(5).toString('hex')}${ext}`);
}});
const upload = multer({storage,fileFilter:(req,file,cb)=>{
  if(file.mimetype==='application/pdf' || path.extname(file.originalname).toLowerCase()==='.pdf') cb(null,true); else cb(new Error('PDF فقط مسموح به'));
},limits:{fileSize:20*1024*1024}});

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(ROOT,'public')));

app.post('/api/auth/login',(req,res)=>{
  const {identifier,password}=req.body;
  const u=db.users.find(x=>x.email===identifier || x.phone===identifier);
  if(!u || !bcrypt.compareSync(password||'',u.password)) return res.status(401).json({message:'البريد/الهاتف أو كلمة المرور غير صحيحة'});
  const token=jwt.sign({id:u.id,role:u.role,name:u.name},JWT_SECRET,{expiresIn:'7d'});
  res.json({token,user:publicUser(u)});
});
app.post('/api/auth/register',(req,res)=>{
  const {name,email,password,grade}=req.body;
  if(!name||!email||!password) return res.status(400).json({message:'أكمل البيانات المطلوبة'});
  if(db.users.some(u=>u.email===email)) return res.status(409).json({message:'البريد مستخدم بالفعل'});
  const u={id:'student-'+crypto.randomUUID(),name,email,phone:'',password:bcrypt.hashSync(password,10),role:'student',grade:grade||'الثانية الثانوية باكالوريا'};
  db.users.push(u);save();res.status(201).json({message:'تم إنشاء الحساب',user:publicUser(u)});
});
app.get('/api/me',auth,(req,res)=>{const u=db.users.find(x=>x.id===req.user.id);res.json(publicUser(u));});
app.get('/api/dashboard',auth,(req,res)=>{
  const user=db.users.find(x=>x.id===req.user.id);
  res.json({user:publicUser(user),materials:db.materials,lessons:db.lessons,exams:db.exams,pdfs:db.pdfs.filter(p=>p.published || req.user.role==='admin')});
});
app.post('/api/admin/pdfs',auth,admin,upload.single('file'),(req,res)=>{
  if(!req.file) return res.status(400).json({message:'اختر ملف PDF'});
  const item={id:'pdf-'+crypto.randomUUID(),title:req.body.title||req.file.originalname,description:req.body.description||'',type:req.body.type||'واجب',grade:req.body.grade||'الثانية الثانوية باكالوريا',unit:req.body.unit||'عام',published:req.body.published==='true',originalName:req.file.originalname,fileName:req.file.filename,url:'/uploads/'+req.file.filename,createdAt:new Date().toISOString(),createdBy:req.user.id};
  db.pdfs.unshift(item);save();res.status(201).json(item);
});
app.put('/api/admin/pdfs/:id',auth,admin,(req,res)=>{const p=db.pdfs.find(x=>x.id===req.params.id);if(!p)return res.status(404).json({message:'الملف غير موجود'});Object.assign(p,{title:req.body.title??p.title,description:req.body.description??p.description,type:req.body.type??p.type,grade:req.body.grade??p.grade,unit:req.body.unit??p.unit,published:req.body.published??p.published});save();res.json(p);});
app.delete('/api/admin/pdfs/:id',auth,admin,(req,res)=>{const i=db.pdfs.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({message:'الملف غير موجود'});const p=db.pdfs[i];try{fs.unlinkSync(path.join(UPLOAD_DIR,p.fileName));}catch{}db.pdfs.splice(i,1);save();res.json({ok:true});});
app.post('/api/admin/lessons',auth,admin,(req,res)=>{const l={id:'lesson-'+crypto.randomUUID(),title:req.body.title,description:req.body.description||'',grade:req.body.grade||'الثانية الثانوية باكالوريا',unit:req.body.unit||'',videoUrl:req.body.videoUrl||'',duration:req.body.duration||'',createdAt:new Date().toISOString()};db.lessons.unshift(l);save();res.status(201).json(l);});
app.delete('/api/admin/lessons/:id',auth,admin,(req,res)=>{db.lessons=db.lessons.filter(x=>x.id!==req.params.id);save();res.json({ok:true});});
app.post('/api/admin/exams',auth,admin,(req,res)=>{const e={id:'exam-'+crypto.randomUUID(),title:req.body.title,grade:req.body.grade||'الثانية الثانوية باكالوريا',unit:req.body.unit||'',questions:Number(req.body.questions||0),duration:Number(req.body.duration||0),published:req.body.published!=='false',createdAt:new Date().toISOString()};db.exams.unshift(e);save();res.status(201).json(e);});
app.delete('/api/admin/exams/:id',auth,admin,(req,res)=>{db.exams=db.exams.filter(x=>x.id!==req.params.id);save();res.json({ok:true});});
app.get('/api/admin/users',auth,admin,(req,res)=>res.json(db.users.map(publicUser)));
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.use((err,req,res,next)=>res.status(400).json({message:err.message||'حدث خطأ'}));
app.listen(PORT,()=>console.log(`Platform running on http://localhost:${PORT}`));
